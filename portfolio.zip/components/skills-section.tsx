import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Code, Database, Globe, Layout, Palette, Server } from "lucide-react"

export function SkillsSection() {
  const skillCategories = [
    {
      title: "Frontend Development",
      description: "Creating responsive and interactive user interfaces",
      icon: <Layout className="h-10 w-10 text-primary" />,
      skills: ["React", "Next.js", "TypeScript", "HTML/CSS", "Tailwind CSS", "Redux"],
    },
    {
      title: "Backend Development",
      description: "Building robust server-side applications",
      icon: <Server className="h-10 w-10 text-primary" />,
      skills: ["Node.js", "Express", "Python", "Django", "RESTful APIs", "GraphQL"],
    },
    {
      title: "Database",
      description: "Managing and optimizing data storage",
      icon: <Database className="h-10 w-10 text-primary" />,
      skills: ["MongoDB", "PostgreSQL", "MySQL", "Firebase", "Redis", "Prisma"],
    },
    {
      title: "UI/UX Design",
      description: "Creating beautiful and intuitive user experiences",
      icon: <Palette className="h-10 w-10 text-primary" />,
      skills: ["Figma", "Adobe XD", "Responsive Design", "Wireframing", "Prototyping", "User Testing"],
    },
    {
      title: "DevOps",
      description: "Streamlining development and deployment processes",
      icon: <Code className="h-10 w-10 text-primary" />,
      skills: ["Git", "Docker", "CI/CD", "AWS", "Vercel", "GitHub Actions"],
    },
    {
      title: "Other Skills",
      description: "Additional technical capabilities",
      icon: <Globe className="h-10 w-10 text-primary" />,
      skills: ["Testing", "Performance Optimization", "SEO", "Accessibility", "PWAs", "WebSockets"],
    },
  ]

  return (
    <section id="skills" className="py-12 md:py-24">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Skills & Expertise</h2>
            <p className="max-w-[700px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              Technologies and tools I work with
            </p>
          </div>
        </div>
        <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 py-12 md:grid-cols-2 lg:grid-cols-3">
          {skillCategories.map((category, index) => (
            <Card key={index}>
              <CardHeader className="pb-2">
                <div className="mb-2">{category.icon}</div>
                <CardTitle>{category.title}</CardTitle>
                <CardDescription>{category.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="grid grid-cols-2 gap-2 text-sm">
                  {category.skills.map((skill, skillIndex) => (
                    <li key={skillIndex} className="flex items-center">
                      <div className="mr-2 h-1.5 w-1.5 rounded-full bg-primary"></div>
                      {skill}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

